"use client";
import { RootState } from "@/redux/store";
import { useDispatch, useSelector } from "react-redux";
import { increment, decrement } from "@/redux/counter-reducer";
export default function Home() {
  const { count } = useSelector((state: RootState) => state.counter);
  const dispatch = useDispatch();
  return (
    <div className="text-center mt-[200px] ">
      <h2 className="font-semibold text-2xl mb-5">{count}</h2>
      <div className="flex gap-5 justify-center">
        <button
          className="px-3 py-1 rounded-lg  border-black border"
          onClick={() => dispatch(increment())}
        >
          +
        </button>
        <button
          className="px-3 py-1 rounded-lg  border-black border"
          onClick={() => dispatch(decrement())}
        >
          -
        </button>
      </div>
    </div>
  );
}
