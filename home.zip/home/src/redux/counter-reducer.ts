import { createSlice } from "@reduxjs/toolkit";
import type { PayloadAction } from '@reduxjs/toolkit'
import exp from "constants";
import { stat } from "fs";


interface CounterState {
    count: number
}

const initialState: CounterState = {
    count: 0
}

const counterSlice = createSlice({
    name: "counter",
    initialState,
    reducers: {
        increment:(state)=> {
            return { ...state, count: state.count + 1 }
        },
        decrement:(state)=> {
            return { ...state, count: state.count - 1 }
        },
        setValue:(state,action:PayloadAction<number>)=>{
            return {...state,count:action.payload}
        }
    }
})

export default counterSlice.reducer
export const {increment,decrement,setValue}=counterSlice.actions